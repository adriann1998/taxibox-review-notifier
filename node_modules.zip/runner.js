const { main } = require("./main");
const start = async () => {
  const result = await main();
};

start();